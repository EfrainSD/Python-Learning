def isEven(num):
    if num % 2 == 0:
        return True
    else:
        return False
    
def add(num1, num2):
    return num1 + num2