# This is for package for package
from setuptools import setup

setup(
    name="miFunction",
    version="1.0",
    description="packageTest",
    author="me",
    author_email="me@me.com",
    url="https://www-me-es",
    packages=["packages"]) # If we had packages inside the package, we would also have to put the names